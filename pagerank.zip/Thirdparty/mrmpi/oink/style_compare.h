#ifdef COMPARE_STYLE


#else


#endif
